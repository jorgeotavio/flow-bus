# Flow Bus

This application was created to improve information about bus stops and times that go to UAST-UFRPE.

Created in Vitejs with Reactjs, to start, run `npm install`, after `npm run dev`.  

## Author
| [<img src="https://avatars.githubusercontent.com/jorgeotavio?s=115"><br><sub>Jorge Otávio</sub>](https://github.com/jorgeotavio) |
| :---: |
